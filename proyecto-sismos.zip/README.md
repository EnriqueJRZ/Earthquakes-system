# Proyecto Sismos

Este proyecto analiza datos de sismos usando PostgreSQL, Python (ETL) y Mondrian (OLAP).

## 📦 Requisitos
- Docker
- Docker Compose
- Cuenta en GitHub o Replit (opcional para Codespaces)

## 🚀 Cómo iniciar

1. Clona el repo:
```bash
git clone https://github.com/tuusuario/proyecto-sismos.git
cd proyecto-sismos
```

2. Inicia el entorno:
```bash
docker-compose up --build
```

3. Accede a:
- PostgreSQL en `localhost:5432`
- Mondrian en `http://localhost:8080`

## 📁 Archivos
- `docker-compose.yml`: define servicios
- `init.sql`: crea tabla `sismos`
- `etl.py`: carga datos simulados
- `mondrian.xml`: define cubo OLAP
