CREATE TABLE sismos (
    id SERIAL PRIMARY KEY,
    fecha DATE,
    magnitud NUMERIC,
    ubicacion TEXT
);

-- Inserta un dato de prueba
INSERT INTO sismos (fecha, magnitud, ubicacion)
VALUES ('2024-06-01', 5.6, 'Guerrero');
