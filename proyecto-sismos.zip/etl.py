import psycopg2

conn = psycopg2.connect(
    host="db",
    database="sismos_db",
    user="usuario",
    password="contraseña"
)

cur = conn.cursor()

# Simulación de carga ETL
sismos = [
    ("2024-06-02", 4.8, "Oaxaca"),
    ("2024-06-03", 6.1, "CDMX")
]

for s in sismos:
    cur.execute("INSERT INTO sismos (fecha, magnitud, ubicacion) VALUES (%s, %s, %s)", s)

conn.commit()
cur.close()
conn.close()
